package br.com.dburger.gestao

import br.com.dburger.gestao.domain.CalculadoraFinanceira
import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal

class CalculadoraFinanceiraTest {

    @Test
    fun testPrecificacaoFormulaExata() {
        val params = CalculadoraFinanceira.ParametrosPrecificacao(
            cmv = BigDecimal("10.00"),
            custoFixoUnitario = BigDecimal("2.00"),
            taxaPagamentoPercent = BigDecimal("0.70"),
            reservaOperacionalPercent = BigDecimal("12.10"),
            margemAlvoPercent = BigDecimal("25.00"),
            precoVendaAtual = BigDecimal("22.00")
        )

        val resultado = CalculadoraFinanceira.calcularPrecificacao(params)

        // Denominador = 1 - 0.007 - 0.121 - 0.250 = 0.622
        // Preço recomendado = 12.00 / 0.622 = 19.29
        assertEquals(BigDecimal("19.29"), resultado.precoRecomendado)
        assertEquals("VERDE", resultado.statusCor)
    }

    @Test
    fun testCustoMedioPonderado() {
        // 10.000g a R$ 0,0300 + 10.000g compradas por R$ 400,00 -> média 0,0350
        val (novoEstoque, novoCusto) = CalculadoraFinanceira.calcularCustoMedioPonderado(
            qtdAtual = 10000.0,
            custoAtual = 0.030,
            qtdComprada = 10000.0,
            valorTotalCompra = 400.0
        )

        assertEquals(20000.0, novoEstoque, 0.01)
        assertEquals(0.035, novoCusto, 0.001)
    }
}
